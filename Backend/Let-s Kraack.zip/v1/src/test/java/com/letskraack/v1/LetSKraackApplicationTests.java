package com.letskraack.v1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LetSKraackApplicationTests {

	@Test
	void contextLoads() {
	}

}
