package com.letskraack.v1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LetSKraackApplication {

	public static void main(String[] args) {
		SpringApplication.run(LetSKraackApplication.class, args);
	}

}
